export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"], // 必要に応じて修正
  theme: {
    extend: {},
  },
  plugins: [require('@tailwindcss/typography')],
}
