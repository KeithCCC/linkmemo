import React from 'react'

export default function SettingsScreen() {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">設定</h2>
      <p className="mt-2">テーマやアプリ情報などの設定をここに。</p>
    </div>
  )
}
