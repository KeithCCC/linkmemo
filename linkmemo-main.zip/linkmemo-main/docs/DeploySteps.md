  64 git add .
  65 git commit -m "Changed title"
  66 git push
  67 npm run build
  68 firebase deploy